Essa é uma implementação de uma Lista Encadeada simples, em que sempre temos acesso a HEAD e ao TAIL da lista. Essa é uma estrutura de dados na qual os elementos são organizados em nós, onde cada nó contém um valor e um ponteiro para o próximo nó.

No arquivo 'linked.hpp' está a classe 'node' com seus getters e setters, e a classe 'ListaEncadeada' com as assinaturas dos métodos da lista.

Para utilizar basta acessar a pasta onde os arquivos estão localizados via terminal, digitar o comando 'make', que irá compilar os arquivos e formar o executável 'main'. Depois disso, basta executar o arquivo 'main' e utilizar o seguinte menu:

"Menu:
1. Adicionar elemento no início
2. Adicionar elemento no final
3. Remover elemento do início
4. Remover elemento do final
5. Imprimir todos os elementos
6. Remover elemento específico
7. Verificar se um elemento existe
8. Excluir todos os elementos
9. Imprimir tamanho atual da lista
0. Sair
Escolha uma opção: "

O usuário pode escolher uma opção digitando o número correspondente.

