Essa é uma implementação básica de uma lista sequencial. Elá sendo inicializada com o tamanho fixo 10 e não há como o usuário aumentar ou diminuir seu tamanho. 

As suas funções são: inserir no front, no back ou em um índice; remover o front, o back ou em um índice; mostrar o número de elementos presentes na lista; encontrar um elemento em um index ou encontrar um elemento pelo seu valor e mostrar seu índice; imprimir todos os elementos presentes na lista; apagar todos os elementos e reiniciar a lista; ordenar os elementos de forma decrescente ou crescente.

É preciso entrar na pasta via terminal e digitar o comando "make" para compilar o programa, e depois "./main" para executar o programa







